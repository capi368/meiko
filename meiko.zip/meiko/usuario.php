
<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
include "php/baseDeDatos.php";

class Usuario
{
	public function consultarUsuario($query = null)
	{
		$bd = new BaseDeDatos("dbmeiko","tbusuario");
		$data = $bd->consultarData($query);
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Records'] = $data;
		print json_encode($jTableResult);
	}	
	public function crearUsuario($query = null) 
	{
		$bd = new BaseDeDatos("dbmeiko","tbusuario");
		$data = $bd->insertarData($query);
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Record'] = $data;
		print json_encode($jTableResult);
	}
	public function editarUsuario($query = null)
	{
		$bd = new BaseDeDatos("dbmeiko","tbusuario");
		$data = $bd->actualizarData($query);
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Record'] = $data;
		print json_encode($jTableResult);
	}
	public function eliminarUsuario($query)
	{
		$bd = new BaseDeDatos("dbmeiko","tbusuario");
		$data = $bd->eliminarData($query);
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Record'] = $data;
		print json_encode($jTableResult);
	}
	
}

if ($_GET['action']=="consultar") {
	$query = "SELECT idusuario, nombre, apellido,pais,rol,username,password FROM tbusuario";
	$usuario = new Usuario();
	$usuario->consultarUsuario($query);
}
else if($_GET['action']=="crear") {
	$nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
	$pais = $_POST['pais'];
	$rol = $_POST['rol'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "INSERT INTO tbusuario (nombre,apellido,pais,rol,username,password)  VALUES ('$nombre','$apellido', '$pais', '$rol','$username','$password')";	
	$usuario = new Usuario();
	$usuario->crearUsuario($query);
}
else if($_GET['action']=="editar") {
	$id = $_POST['idusuario'];
	$nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
	$pais = $_POST['pais'];
	$rol = $_POST['rol'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "UPDATE tbusuario SET nombre='$nombre',apellido='$apellido',pais='$pais',rol='$rol',username='$username',password='$password'
				where idusuario = $id";
	$usuario = new Usuario();
	$usuario->editarUsuario($query);			
}
else if($_GET['action']=="eliminar") {
	$id = $_POST['idusuario'];
	$query = "DELETE FROM tbusuario 
				where idusuario = $id";
	$usuario = new Usuario();
	$usuario->eliminarUsuario($query);			
}
	
?>