<?php
// Set required headers
//header('Content-Type: application/json; charset=utf-8');
//header('Access-Control-Allow-Origin: *');

//$data = $_POST['datosFormulario']
//recibirDatos();
$myObj->name = "John";
$myObj->age = 30;
$myObj->city = "New York";

$myJSON = json_encode($myObj);

echo $myJSON;

 function recibirDatos(){

	if (!empty($_POST)){
		if ($data["username"] != "" && $data["password"] != "") {
						
		}	
	}
 }
		 
    




?>