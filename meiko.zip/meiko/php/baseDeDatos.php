<?php
/*
@author: David Lozano
@Date: Enero 2020
Clase BaseDeDatos que se encarga de conectar servicio con la base de datos
y encargarse de los procesos CRUD
*/
class BaseDeDatos 
{
	private $localHost = "127.0.0.1";
	private $usuario = "root";
	private $password = "";
	private $baseDatos = null;
	private $enlace = null;
	private $tabla = null;
	private $query = null;
	private $data = null;
	
	public function __construct($baseDatos=null,$tabla=null)
	{
		$this->baseDatos = $baseDatos;
		$this->tabla = $tabla;
	    $this->conectarBD();
	}
	function __destruct() {
		
	}
	
	public function conectarBD()
	{
	  $this->enlace = mysqli_connect($this->localHost, $this->usuario, $this->password, $this->baseDatos);
		if (!$this->enlace) {
			echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
			echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
			echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
			exit;
		}

   }
   public function consultarData($query = null) 
   {
	  
		$result = mysqli_query($this->enlace, $query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result)) {
			  $this->data[] = $row;
			}
		}
		else {
			$this->data = "Error";
		}
		$this->cerrarBD();
	    return $this->data;
   }
   
   public function actualizarData($query = null)
   {
	   mysqli_query($this->enlace, $query);
	   $this->data = mysqli_insert_id($this->enlace);
	   return $this->data;
	   $this->cerrarBD();
   }
   
   public function insertarData($query = null)
   {
	   mysqli_query($this->enlace, $query);
	   $this->data = mysqli_insert_id($this->enlace);
	   return $this->data;
	   $this->cerrarBD();
   }   
   public function eliminarData($query)
   {
	   mysqli_query($this->enlace, $query);
	   $this->data = mysqli_insert_id($this->enlace);
	   return $this->data;
	   $this->cerrarBD();
   }
   public function cerrarBD()
   {
		mysqli_close($this->enlace);
   }
   
}

/*$pwd = "david";

$query = "Select idusuario, nombre,apellido,pais,rol,username,password from tbusuario where password = '$pwd'";
$bd = new BaseDeDatos("dbmeiko","tbusuario");
$data = $bd->consultarData($query);
var_dump($data[0]['idusuario'])*/


		
?>   