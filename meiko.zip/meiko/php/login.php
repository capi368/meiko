<?php
include "baseDeDatos.php";
// Set required headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$data = $_POST['datosFormulario'];
recibirDatos($data);

 function recibirDatos($data){
	$myObj=new \stdClass();
	if (!empty($_POST)){
		if ($data["username"] != "" && $data["password"] != "") {
			$pwd = $data["password"];
			$un = $data["username"];
			$query = "Select idusuario, nombre,apellido,pais,rol,username,password from tbusuario where username = '$un' and password = '$pwd'";
			$bd = new BaseDeDatos("dbmeiko","tbusuario");
			$datos = $bd->consultarData($query);
			if ($datos != "Error") {
				$myObj->status = 1;
				$myObj->statusText = "Exito";
				$myObj->username = $datos[0]['username'];
				$myObj->idusuario = $datos[0]['idusuario'];
				$myObj->idusuario = $datos[0]['rol'];
				$myObj->rol = $datos[0]['rol'];
				if ($myObj->rol == "admin") {
					$myObj->pagina = "prueba-meiko.html";
				}
				else {
					$myObj->pagina = "prueba-meiko2.html";
				}
			}
			else {
				
				$myObj->status = 0;
				$myObj->statusText = "Error";
			}
			$myJSON = json_encode($myObj);
			echo $myJSON;			
		}	
	}
 }
		 
    




?>