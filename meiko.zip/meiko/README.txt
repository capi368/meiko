# Prueba Meiko Por David Lozano

_Prueba para proceso de seleccion en Meiko_

## Comenzando 🚀

_Estas instrucciones permiten obtener una copia del proyecto en funcionamiento en máquina local para propósitos de pruebas._

Mira **Deployment** para conocer como desplegar el proyecto.


### Pre-requisitos 📋

_Motor de base de datos MySql, servidor apache o nginx y php5 o superior ____

```

```

### Instalación 🔧

_Basta con descargar el archivo comprimido y desempaquetar los archivos html y archivos php y ubicarlos en una carpeta en el servidor. Por otra parte 
hay que ejecutar el archivo meiko.sql para crear la base de datos con las tablas necesarias para el ejercicio_

_ _

```


### Ejecucion 🔧

_Para ejecutar las pruebas es necesario lo siguiente:_

_desde el navegador de internet ejecutar la pagina meiko/login.html _
_ Para la prueba de usuario administrador los datos de ingreso son: _
_ username: david , password: david _
_El sistema lo lleva al dashboard de gestion de usuarios para visualizar, crear, editar y eliminar _
_Para la prueba con un usuario normal puede usar el username diana y password diana _
_El sistema lo lleva al dashboard de solo consulta de usuarios _



_  _

```

## Construido con 🛠️

_Herramientas utilizadas en e proyecto_

* [jtable](http://jtable.org/) - Libreria para el uso de datos en tablas dinamicas



## Autores ✒️


* **Robinson David Lozano Ortiz** - *Trabajo Inicial* - [capi368](https://github.com/capi368)




## Licencia 📄

Este proyecto no tiene ninguna Licencia y puede ser usado libremente para el ejercicio de proceso de seleccion




