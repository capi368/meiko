/*
SQLyog Community v8.71 
MySQL - 5.5.5-10.1.30-MariaDB : Database - dbmeiko
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbmeiko` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbmeiko`;

/*Table structure for table `tbusuario` */

DROP TABLE IF EXISTS `tbusuario`;

CREATE TABLE `tbusuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) DEFAULT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `pais` varchar(30) DEFAULT NULL,
  `rol` varchar(10) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `tbusuario` */

insert  into `tbusuario`(`idusuario`,`nombre`,`apellido`,`pais`,`rol`,`username`,`password`) values (1,'Robinson David','Lozano Ortiz','AR','admin','david','david'),(2,'Ana','Rodriguez','Colombia','consulta','ana','ana'),(3,'Diana','Gomez','Argentina','consulta','diana','diana'),(5,'Robinson','Lozano','BR','admin','$username','$password'),(8,'Claudia','Rozo','Colombia','admin','admin','admin'),(10,'Claudia','Rozo','Colombia','admin','admin','admin'),(11,'Adriana','Rodriguez','BR','consulta','adriana','adriana'),(12,'Isabel','Mendoza','CO','admin','isabel','isabel');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
