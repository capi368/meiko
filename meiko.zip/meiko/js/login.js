/**
 * @author:  David Lozano
 * Date:  Enero 23 2020
 * Script que captura datos login para enviarlos al servidor y dar respuesta al usuario si es valido o no
 */
$(document).ready(function(){
  
   $("#enviar").click(function(){
	   var datosFormulario = {
			username : $("#username").val(), 
			password : $("#password").val()
	   };
          
          $.post("php/login.php", {datosFormulario}, function(result){
			if (result.status == 1) {
				window.location.replace('/meiko/'+result.pagina);
			}
			else{
				
				alert("Acceso Denegado");
			}
          });   

    });
});


